## 1
### 1.1
library(ggplot2)
library(dplyr)

adsl <- haven::read_sas("data/adsl.sas7bdat")

f <- function(adsl, title) {
    ggplot(adsl, aes(BHEIGHT, BWEIGHT, color = ARM)) +
        geom_point() +
        geom_smooth() +
        ggtitle(title)
}
f(adsl, "Baseline Weight to Height Correlation")


### 1.2
f <- function(adsl, title, split = FALSE) {
    p <- ggplot(adsl, aes(BHEIGHT, BWEIGHT, color = ARM)) +
        geom_point() +
        geom_smooth() +
        ggtitle(title)
    if(split) p <- p + facet_wrap(~SEX)
    p
}
f(adsl, "Baseline Weight to Height Correlation")
f(adsl, "Baseline Weight to Height Correlation", split = TRUE)
